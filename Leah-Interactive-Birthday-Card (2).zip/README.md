# Leah's folding birthday card — From Zac ♡

A static shareable birthday card that uses the original three supplied images unchanged. It simulates a physical folded card: the photo-collage cover folds open to reveal the original handwritten letter, then the letter leaf turns to reveal the original heart ending. The spine, reverse paper surfaces, page thickness, and shadows respond to the flip. You can turn backward, jump directly to any page, swipe on mobile, zoom into any page, and hover over the cover to magnify the collage.

## Local preview

Open `index.html` in a modern browser, or run `python3 -m http.server 8080` in this folder and visit `http://localhost:8080`.

## Publishing the changes to your Netlify URL

The site at `birthdaygiftforleah.netlify.app` is not modified by this export. Use Netlify's dashboard for the existing site to deploy the contents of this `leah-card-site` folder (including `index.html`, `assets`, and `vercel.json`), or drag-and-drop the prepared ZIP via its deployment UI if supported. A new site rather than the existing site's deploy area would get a different URL.

## Page flip audio

The website attempts to play a real recording of a single paper page turn from Mixkit, "Page turn single" (Mixkit Free License): `https://assets.mixkit.co/active_storage/sfx/1104/1104-preview.mp3`. It is loaded online when someone turns the page. If the recording is blocked or the card is opened offline, the original low-volume bundled WAV is used as a fallback. There are no electronic oscillators or sound effects in the new design. Sound can be turned off at any time.

## Notes

- The original three art images are not edited.
- No framework, database, trackers, fonts, or accounts required to view.
- The public link may be viewed by anyone who has it; use a host's password/access control for a private card.
- The `vercel.json` is only relevant if deploying to Vercel; Netlify ignores it.
